This directory includes Complex Type + MIME attachment example
by Ger Apeldoorn <g.apeldoorn at argoss dot nl>
Thanks.
