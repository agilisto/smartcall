#!/bin/sh -

ruby -Ks wsdlDriver.rb 'Ruby �Ȃ�'
