1. run wsdl2ruby.rb againt ndfdXML.wsdl

% bin/wsdl2ruby.rb --wsdl ndfdXML.wsdl --type client --force

2. run client.rb to see how it works.
