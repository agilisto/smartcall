Clients/Server for SOAPBuilders Interoperability Lab "Round 2"
http://www.whitemesa.com/interop.htm
