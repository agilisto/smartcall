require 'echo_version.rb'
require'soap/mapping'
moduleEcho_versionMappingRegistry  EncodedRegistry=::SOAP::Mapping::EncodedRegistry.newLiteralRegistry=::SOAP::Mapping::LiteralRegistry.new
  end