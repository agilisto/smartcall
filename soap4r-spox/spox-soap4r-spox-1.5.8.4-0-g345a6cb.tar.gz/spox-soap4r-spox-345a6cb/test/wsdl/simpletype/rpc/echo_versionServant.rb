require 'echo_version.rb'

classEcho_version_port_typeend
